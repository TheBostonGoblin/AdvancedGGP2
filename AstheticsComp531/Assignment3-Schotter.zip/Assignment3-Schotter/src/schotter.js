const svgContainer = document.querySelector("#container");

async function feching(){
    const svg = await fetch("./img/tile2.svg");
    const svgText  = await svg.text();
    let totalText;
    for(let x = 0; x < 12;x++){
        for(let y = 0; y<22;y++)
        {
            debugger;
            let svg = document.createElement("g");
            svg.innerHTML = svgText;

            svg.setAttribute("transform",`translate(${x*64},${y*64})`);
            svgContainer.appendChild(svg);
        }
    }
    console.log("Hello");
}

feching();


