#include "Sky.h"
using namespace DirectX;

#include "packages/directxtk_desktop_2017.2020.2.24.4/include/WICTextureLoader.h"
#include "packages/directxtk_desktop_2017.2020.2.24.4/include/DDSTextureLoader.h"
#include "Helpers.h"
//#include "WICTextureLoader.h"
//#include "DDSTextureLoader.h"
#define LoadShader(type, file) std::make_shared<type>(device.Get(), context.Get(), FixPath(file).c_str())


Sky::Sky(
	const wchar_t* cubemapDDSFile, 
	std::shared_ptr<Mesh> mesh,
	std::shared_ptr<SimpleVertexShader> skyVS, 
	std::shared_ptr<SimplePixelShader> skyPS, 
	Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerOptions, 
	Microsoft::WRL::ComPtr<ID3D11Device> device, 
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> context)
{
	// Save params
	this->skyMesh = mesh;
	this->device = device;
	this->context = context;
	this->samplerOptions = samplerOptions;
	this->skyVS = skyVS;
	this->skyPS = skyPS;

	// Init render states
	InitRenderStates();

	// Load texture
	CreateDDSTextureFromFile(device.Get(), cubemapDDSFile, 0, skySRV.GetAddressOf());
}

Sky::Sky(
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeMap,
	Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerOptions,
	Microsoft::WRL::ComPtr<ID3D11Device> device,
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> context) :
	skySRV(cubeMap),
	samplerOptions(samplerOptions),
	device(device),
	context(context)
{
	// Init render states
	InitRenderStates();
}

Sky::Sky(
	const wchar_t* right, 
	const wchar_t* left, 
	const wchar_t* up, 
	const wchar_t* down, 
	const wchar_t* front, 
	const wchar_t* back, 
	std::shared_ptr<Mesh> mesh,
	std::shared_ptr<SimpleVertexShader> skyVS,
	std::shared_ptr<SimplePixelShader> skyPS,
	Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerOptions,
	Microsoft::WRL::ComPtr<ID3D11Device> device,
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> context)
{

	
	
	// Save params
	this->skyMesh = mesh;
	this->device = device;
	this->context = context;
	this->samplerOptions = samplerOptions;
	this->skyVS = skyVS;
	this->skyPS = skyPS;

	computeShader = LoadShader(SimpleComputeShader, L"SkyShiftComputeShader.cso");
	// Init render states
	InitRenderStates();

	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Night\\right.png").c_str(), 0, nightSkyTextures[0].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Night\\left.png").c_str(), 0, nightSkyTextures[1].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Night\\up.png").c_str(), 0, nightSkyTextures[2].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Night\\down.png").c_str(), 0, nightSkyTextures[3].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Night\\front.png").c_str(), 0, nightSkyTextures[4].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Night\\back.png").c_str(), 0, nightSkyTextures[5].GetAddressOf());

	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Clouds Blue\\right.png").c_str(), 0, daySkyTextures[0].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Clouds Blue\\left.png").c_str(), 0, daySkyTextures[1].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Clouds Blue\\up.png").c_str(), 0, daySkyTextures[2].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Clouds Blue\\down.png").c_str(), 0, daySkyTextures[3].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Clouds Blue\\front.png").c_str(), 0, daySkyTextures[4].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), FixPath(L"..\\..\\Assets\\Skies\\Clouds Blue\\back.png").c_str(), 0, daySkyTextures[5].GetAddressOf());

	computeShaderSkyShiftDay();

	
	// Create texture from 6 images
	skySRV = CreateCubemap(right, left, up, down, front, back);

	// Build IBL Maps
	IBLCreateIrradianceMap();
	IBLCreateConvolvedSpecularMap();
	IBLCreateBRDFLookUpTexture();
}

Sky::Sky(
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> right,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> left,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> up,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> down,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> front,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> back,
	std::shared_ptr<Mesh> mesh,
	std::shared_ptr<SimpleVertexShader> skyVS,
	std::shared_ptr<SimplePixelShader> skyPS,
	Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerOptions,
	Microsoft::WRL::ComPtr<ID3D11Device> device,
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> context)
{
	// Save params
	this->skyMesh = mesh;
	this->device = device;
	this->context = context;
	this->samplerOptions = samplerOptions;
	this->skyVS = skyVS;
	this->skyPS = skyPS;

	// Init render states
	InitRenderStates();



	// Create texture from 6 images
	skySRV = CreateCubemap(right, left, up, down, front, back);
}

Sky::~Sky()
{

}

void Sky::Draw(std::shared_ptr<Camera> camera)
{
	// setting compute shader
	computeShader->SetShader();
	computeShader->SetUnorderedAccessView("cubeMap", unorderedAccessViewCubemap);
	computeShader->SetShaderResourceView("replacementRight", nightSkyTextures[0]);
	computeShader->SetShaderResourceView("replacementLeft", nightSkyTextures[1]);
	computeShader->SetShaderResourceView("replacementUp", nightSkyTextures[2]);
	computeShader->SetShaderResourceView("replacementDown", nightSkyTextures[3]);
	computeShader->SetShaderResourceView("replacementFront", nightSkyTextures[4]);
	computeShader->SetShaderResourceView("replacementBack", nightSkyTextures[5]);

	computeShader->SetShaderResourceView("currentRight", daySkyTextures[0]);
	computeShader->SetShaderResourceView("currentLeft", daySkyTextures[1]);
	computeShader->SetShaderResourceView("currentUp", daySkyTextures[2]);
	computeShader->SetShaderResourceView("currentDown", daySkyTextures[3]);
	computeShader->SetShaderResourceView("currentFront", daySkyTextures[4]);
	computeShader->SetShaderResourceView("currentBack", daySkyTextures[5]);

	computeShader->SetFloat("currentInterpolationPercent", currentTextureInterpolation);
	computeShader->CopyBufferData("skyShiftVar");

	if (interoplatingToNewTexture)
	{
		currentTextureInterpolation += skyDeltaTime / 100;//milliseconds
		if (currentTextureInterpolation > 1) 
			currentTextureInterpolation = 1;
	}
	else
	{
		currentTextureInterpolation -= skyDeltaTime / 100;//milliseconds
		if (currentTextureInterpolation < 0)
			currentTextureInterpolation = 0;
	}

	if (currentTextureInterpolation >= 1.0f) 
	{
		interoplatingToNewTexture = false;
		//currentTextureInterpolation -= skyDeltaTime / 1000;//milliseconds
	}
	else if(currentTextureInterpolation <= 0)
	{
		interoplatingToNewTexture = true;
	}

	

	//dispatching compute shader
	context->Dispatch(256, 256, 1);

	ID3D11UnorderedAccessView* nullUAV[] = { NULL };
	context->CSSetUnorderedAccessViews(0, 1, nullUAV, 0);

	// Change to the sky-specific rasterizer state
	context->RSSetState(skyRasterState.Get());
	context->OMSetDepthStencilState(skyDepthState.Get(), 0);

	// Set the sky shaders
	skyVS->SetShader();
	skyPS->SetShader();

	
	// Give them proper data
	skyVS->SetMatrix4x4("view", camera->GetView());
	skyVS->SetMatrix4x4("projection", camera->GetProjection());
	skyVS->CopyAllBufferData();

	// Send the proper resources to the pixel shader
	skyPS->SetShaderResourceView("skyTexture", skySRV);
	skyPS->SetSamplerState("samplerOptions", samplerOptions);

	// Set mesh buffers and draw
	skyMesh->SetBuffersAndDraw(context);

	// Reset my rasterizer state to the default
	context->RSSetState(0); // Null (or 0) puts back the defaults
	context->OMSetDepthStencilState(0, 0);

}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Sky::GetIrradianceCubeMap()
{
	return irradIBL_Cubemap;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Sky::GetConvolvedSpecularIBL_Cubemap()
{
	return convolvedSpecularIBL_Cubemap;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Sky::GetBRDF_LookupTexture()
{
	return BRDF_Lookup_Texture;
}

int Sky::GetMipMapLevels()
{
	return mipMapLevels;
}

void Sky::InitRenderStates()
{
	// Rasterizer to reverse the cull mode
	D3D11_RASTERIZER_DESC rastDesc = {};
	rastDesc.CullMode = D3D11_CULL_FRONT; // Draw the inside instead of the outside!
	rastDesc.FillMode = D3D11_FILL_SOLID;
	rastDesc.DepthClipEnable = true;
	device->CreateRasterizerState(&rastDesc, skyRasterState.GetAddressOf());

	// Depth state so that we ACCEPT pixels with a depth == 1
	D3D11_DEPTH_STENCIL_DESC depthDesc = {};
	depthDesc.DepthEnable = true;
	depthDesc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
	depthDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
	device->CreateDepthStencilState(&depthDesc, skyDepthState.GetAddressOf());
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Sky::CreateCubemap(
	const wchar_t* right,
	const wchar_t* left,
	const wchar_t* up,
	const wchar_t* down,
	const wchar_t* front,
	const wchar_t* back)
{
	
	// Load the 6 textures into an array.
	// - We need references to the TEXTURES, not the SHADER RESOURCE VIEWS!
	// - Specifically NOT generating mipmaps, as we don't need them for the sky!
	// - Order matters here!  +X, -X, +Y, -Y, +Z, -Z
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> textures[6] = {};
	CreateWICTextureFromFile(device.Get(), right, 0, textures[0].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), left, 0, textures[1].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), up, 0, textures[2].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), down, 0, textures[3].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), front, 0, textures[4].GetAddressOf());
	CreateWICTextureFromFile(device.Get(), back, 0, textures[5].GetAddressOf());

	// Send back the SRV, which is what we need for our shaders
	return CreateCubemap(textures[0], textures[1], textures[2], textures[3], textures[4], textures[5]);
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Sky::CreateCubemap(
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> right,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> left,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> up,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> down,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> front,
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> back)
{
	// Load the 6 textures into an array.
	// - We need references to the TEXTURES, not the SHADER RESOURCE VIEWS!
	// - Order matters here!  +X, -X, +Y, -Y, +Z, -Z
	
	ID3D11Resource* textureResources[6] = {};
	right.Get()->GetResource(&textureResources[0]);
	left.Get()->GetResource(&textureResources[1]);
	up.Get()->GetResource(&textureResources[2]);
	down.Get()->GetResource(&textureResources[3]);
	front.Get()->GetResource(&textureResources[4]);
	back.Get()->GetResource(&textureResources[5]);

	// We'll assume all of the textures are the same color format and resolution,
	// so get the description of the first shader resource view
	D3D11_TEXTURE2D_DESC faceDesc = {};
	((ID3D11Texture2D*)textureResources[0])->GetDesc(&faceDesc);

	// Describe the resource for the cube map, which is simply 
	// a "texture 2d array".  This is a special GPU resource format, 
	// NOT just a C++ array of textures!!!
	D3D11_TEXTURE2D_DESC cubeDesc = {};
	cubeDesc.ArraySize = 6; // Cube map!
	cubeDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_UNORDERED_ACCESS; // We'll be using as a texture in a shader
	cubeDesc.CPUAccessFlags = 0; // No read back
	cubeDesc.Format = faceDesc.Format; // Match the loaded texture's color format
	cubeDesc.Width = faceDesc.Width;  // Match the size
	cubeDesc.Height = faceDesc.Height; // Match the size
	cubeDesc.MipLevels = 1; // Only need 1
	cubeDesc.MiscFlags = D3D11_RESOURCE_MISC_TEXTURECUBE; // This should be treated as a CUBE, not 6 separate textures
	cubeDesc.Usage = D3D11_USAGE_DEFAULT; // Standard usage
	cubeDesc.SampleDesc.Count = 1;
	cubeDesc.SampleDesc.Quality = 0;

	// Create the actual texture resource
	Microsoft::WRL::ComPtr<ID3D11Texture2D> cubeMapTexture;
	device->CreateTexture2D(&cubeDesc, 0, &cubeMapTexture);

	// Loop through the individual face textures and copy them,
	// one at a time, to the cube map texure
	for (int i = 0; i < 6; i++)
	{
		// Calculate the subresource position to copy into
		unsigned int subresource = D3D11CalcSubresource(
			0,	// Which mip (zero, since there's only one)
			i,	// Which array element?
			1); // How many mip levels are in the texture?

		// Copy from one resource (texture) to another
		context->CopySubresourceRegion(
			cubeMapTexture.Get(), // Destination resource
			subresource,		// Dest subresource index (one of the array elements)
			0, 0, 0,			// XYZ location of copy
			textureResources[i],		// Source resource
			0,					// Source subresource index (we're assuming there's only one)
			0);					// Source subresource "box" of data to copy (zero means the whole thing)

	}
	

	// At this point, all of the faces have been copied into the 
	// cube map texture, so we can describe a shader resource view for it
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.Format = cubeDesc.Format; // Same format as texture
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE; // Treat this as a cube!
	srvDesc.TextureCube.MipLevels = 1;	// Only need access to 1 mip
	srvDesc.TextureCube.MostDetailedMip = 0; // Index of the first mip we want to see

	// Make the SRV
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeSRV;
	device->CreateShaderResourceView(cubeMapTexture.Get(), &srvDesc, cubeSRV.GetAddressOf());


	D3D11_UNORDERED_ACCESS_VIEW_DESC descUAV = {};
	memset(&descUAV, 0, sizeof(descUAV));
	descUAV.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	descUAV.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2DARRAY; // Cube maps are ARRAYS of textures
	descUAV.Texture2DArray.MipSlice = 0;
	descUAV.Texture2DArray.FirstArraySlice = 0; // Starting at zero, but we can index in the shader
	descUAV.Texture2DArray.ArraySize = 6; // Need access to all six
	device->CreateUnorderedAccessView(cubeMapTexture.Get(), &descUAV, unorderedAccessViewCubemap.GetAddressOf());


	// Clean up our extra texture refs
	for (int i = 0; i < 6; i++)
		textureResources[i]->Release();


	// Send back the SRV, which is what we need for our shaders
	return cubeSRV;
}

void Sky::IBLCreateIrradianceMap()
{
	// Create the final irradiance cube texture
	D3D11_TEXTURE2D_DESC texDesc = {};
	texDesc.Width = sizeOfIBL_CubemapFace; // One of your constants
	texDesc.Height = sizeOfIBL_CubemapFace; // Same as width
	texDesc.ArraySize = 6; // Cube map means 6 textures
	texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE; // Will be used as both
	texDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; // Basic texture format
	texDesc.MipLevels = 1; // No mip chain needed
	texDesc.MiscFlags = D3D11_RESOURCE_MISC_TEXTURECUBE; // It's a cube map
	texDesc.SampleDesc.Count = 1; // Can't be zero

	Microsoft::WRL::ComPtr<ID3D11Texture2D> irrMapFinalTexture;
	device->CreateTexture2D(&texDesc, 0, irrMapFinalTexture.GetAddressOf());

	// Create an SRV for the irradiance texture
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE; // Sample as a cube map
	srvDesc.TextureCube.MipLevels = 1; // Only 1 mip level
	srvDesc.TextureCube.MostDetailedMip = 0; // Accessing the first (and only) mip
	srvDesc.Format = texDesc.Format; // Same format as texture
	device->CreateShaderResourceView(
		irrMapFinalTexture.Get(), // Texture from previous step
		&srvDesc, // Description from this step
		irradIBL_Cubemap.GetAddressOf()); // Member variable of the Sky class


	// Save current render target and depth buffer
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> prevRTV;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> prevDSV;
	context->OMGetRenderTargets(1, prevRTV.GetAddressOf(), prevDSV.GetAddressOf());
	// Save current viewport
	unsigned int vpCount = 1;
	D3D11_VIEWPORT prevVP = {};
	context->RSGetViewports(&vpCount, &prevVP);

	// Make sure the viewport matches the texture size
	D3D11_VIEWPORT vp = {};
	vp.Width = (float)sizeOfIBL_CubemapFace;
	vp.Height = (float)sizeOfIBL_CubemapFace;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	context->RSSetViewports(1, &vp);
	// Set states that may or may not be set yet
	context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	std::shared_ptr <SimpleVertexShader> fullscreenVS = LoadShader(SimpleVertexShader, L"FullScreenVS.cso");
	std::shared_ptr<SimplePixelShader> irradiancePS = LoadShader(SimplePixelShader, L"IBLIrradianceMapPS.cso");

	fullscreenVS->SetShader();
	irradiancePS->SetShader();
	irradiancePS->SetShaderResourceView("EnvironmentMap", skySRV.Get()); // Skybox texture itself
	irradiancePS->SetSamplerState("BasicSampler", samplerOptions.Get());

	for (int face = 0; face < 6 ; face++)
	{
		// Make a render target view for this face
		D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
		rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY; // This points to a Texture2D Array
		rtvDesc.Texture2DArray.ArraySize = 1; // How much of the array do we need access to?
		rtvDesc.Texture2DArray.FirstArraySlice = face; // Which texture are we rendering into?
		rtvDesc.Texture2DArray.MipSlice = 0; // Which mip are we rendering into?
		rtvDesc.Format = texDesc.Format; // Same format as texture
		// Create the RTV itself
		Microsoft::WRL::ComPtr<ID3D11RenderTargetView> rtv;
		device->CreateRenderTargetView(irrMapFinalTexture.Get(), &rtvDesc, rtv.GetAddressOf());
		// Clear and set this render target
		float black[4] = {}; // Initialize to all zeroes
		context->ClearRenderTargetView(rtv.Get(), black);
		context->OMSetRenderTargets(1, rtv.GetAddressOf(), 0);

		// Per-face shader data and copy
		irradiancePS->SetInt("faceIndex", face);
		irradiancePS->CopyAllBufferData();

		// Render exactly 3 vertices
		context->Draw(3, 0);
		// Ensure we flush the graphics pipe to so that we don't cause
		// a hardware timeout which can result in a driver crash
		// NOTE: This might make C++ sit and wait for a sec! Better than a crash!
		context->Flush();
		// Restore the old render target and viewport
		context->OMSetRenderTargets(1, prevRTV.GetAddressOf(), prevDSV.Get());
		context->RSSetViewports(1, &prevVP);

	}
	

}

void Sky::IBLCreateConvolvedSpecularMap()
{

	// Calculate how many mip levels we'll need, potentially skipping a few of the smaller
// mip levels (1x1, 2x2, etc.) because, with such low resolutions, they're mostly the same.
// (The +1 is necessary to account for the 1x1 mip level)
	mipMapLevels = max((int)(log2(sizeOfIBL_CubemapFace)) + 1 - mipLevelSkip, 1);

	// Create the final specualr cube texture
	D3D11_TEXTURE2D_DESC texDesc = {};
	texDesc.Width = sizeOfIBL_CubemapFace; // One of your constants
	texDesc.Height = sizeOfIBL_CubemapFace; // Same as width
	texDesc.ArraySize = 6; // Cube map means 6 textures
	texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE; // Will be used as both
	texDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; // Basic texture format
	texDesc.MipLevels = mipMapLevels; // No mip chain needed
	texDesc.MiscFlags = D3D11_RESOURCE_MISC_TEXTURECUBE; // It's a cube map
	texDesc.SampleDesc.Count = 1; // Can't be zero
	
	Microsoft::WRL::ComPtr<ID3D11Texture2D> specMapFinalTexture;
	device->CreateTexture2D(&texDesc, 0, specMapFinalTexture.GetAddressOf());

	// Create an SRV for the specualr texture
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE; // Sample as a cube map
	srvDesc.TextureCube.MipLevels = mipMapLevels; // Only 1 mip level
	srvDesc.TextureCube.MostDetailedMip = 0; // Accessing the first (and only) mip
	srvDesc.Format = texDesc.Format; // Same format as texture
	device->CreateShaderResourceView(
		specMapFinalTexture.Get(), // Texture from previous step
		&srvDesc, // Description from this step
		convolvedSpecularIBL_Cubemap.GetAddressOf()); // Member variable of the Sky class

	// Save current render target and depth buffer
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> prevRTV;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> prevDSV;
	context->OMGetRenderTargets(1, prevRTV.GetAddressOf(), prevDSV.GetAddressOf());
	// Save current viewport
	unsigned int vpCount = 1;
	D3D11_VIEWPORT prevVP = {};
	context->RSGetViewports(&vpCount, &prevVP);

	// Set states that may or may not be set yet
	context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	std::shared_ptr <SimpleVertexShader> fullscreenVS = LoadShader(SimpleVertexShader, L"FullScreenVS.cso");
	std::shared_ptr<SimplePixelShader> convolvedSpecPS = LoadShader(SimplePixelShader, L"IBLIrradianceMapPS.cso");

	fullscreenVS->SetShader();
	convolvedSpecPS->SetShader();
	convolvedSpecPS->SetShaderResourceView("EnvironmentMap", skySRV.Get()); // Skybox texture itself
	convolvedSpecPS->SetSamplerState("BasicSampler", samplerOptions.Get());

	for (int currentMipLevel =0; currentMipLevel< mipMapLevels; currentMipLevel++)
	{
		for (int face = 0; face < 6; face++)
		{
			// Make a render target view for this face
			D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
			rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY; // This points to a Texture2D Array
			rtvDesc.Texture2DArray.ArraySize = 1; // How much of the array do we need access to?
			rtvDesc.Texture2DArray.FirstArraySlice = face; // Which texture are we rendering into?
			rtvDesc.Texture2DArray.MipSlice = currentMipLevel; // Which mip are we rendering into?
			rtvDesc.Format = texDesc.Format; // Same format as texture
			// Create the RTV itself
			Microsoft::WRL::ComPtr<ID3D11RenderTargetView> rtv;
			device->CreateRenderTargetView(specMapFinalTexture.Get(), &rtvDesc, rtv.GetAddressOf());
			// Clear and set this render target
			float black[4] = {}; // Initialize to all zeroes
			context->ClearRenderTargetView(rtv.Get(), black);
			context->OMSetRenderTargets(1, rtv.GetAddressOf(), 0);

			// Create a viewport that matches the size of this MIP (The -1 accounts for the 1x1 mip level)
			D3D11_VIEWPORT vp = {};
			vp.Width = (float)pow(2, mipMapLevels + mipLevelSkip - 1 - currentMipLevel);
			vp.Height = vp.Width; // Always square
			vp.MinDepth = 0.0f;
			vp.MaxDepth = 1.0f;
			context->RSSetViewports(1, &vp);
			// Handle per-face shader data and copy
			convolvedSpecPS->SetFloat("roughness", currentMipLevel / (float)(mipMapLevels - 1));
			convolvedSpecPS->SetInt("faceIndex", face);
			convolvedSpecPS->SetInt("mipLevel", currentMipLevel);
			convolvedSpecPS->CopyAllBufferData();

			// Per-face shader data and copy
			convolvedSpecPS->SetInt("faceIndex", face);
			convolvedSpecPS->CopyAllBufferData();

			// Render exactly 3 vertices
			context->Draw(3, 0);
			// Ensure we flush the graphics pipe to so that we don't cause
			// a hardware timeout which can result in a driver crash
			// NOTE: This might make C++ sit and wait for a sec! Better than a crash!
			context->Flush();
			// Restore the old render target and viewport
			context->OMSetRenderTargets(1, prevRTV.GetAddressOf(), prevDSV.Get());
			context->RSSetViewports(1, &prevVP);
		}
	}
	
}

void Sky::IBLCreateBRDFLookUpTexture()
{
	// Create the final irradiance cube texture
	D3D11_TEXTURE2D_DESC texDesc = {};
	texDesc.Width = sizeOfLookupTexture; // One of your constants
	texDesc.Height = sizeOfLookupTexture; // Same as width
	texDesc.ArraySize = 1; // Cube map means 6 textures
	texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE; // Will be used as both
	texDesc.Format = DXGI_FORMAT_R16G16_UNORM; // Basic texture format
	texDesc.MipLevels = 1; // No mip chain needed
	texDesc.MiscFlags = 0; // It's a cube map
	texDesc.SampleDesc.Count = 1; // Can't be zero'

	Microsoft::WRL::ComPtr<ID3D11Texture2D> finalLookupTexture;
	device->CreateTexture2D(&texDesc, 0, finalLookupTexture.GetAddressOf());

	// Create an SRV for the BRDF look-up texture
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; // Just a regular 2d texture
	srvDesc.Texture2D.MipLevels = 1; // Just one mip
	srvDesc.Texture2D.MostDetailedMip = 0; // Accessing the first (and only) mip
	srvDesc.Format = texDesc.Format; // Same format as texture
	device->CreateShaderResourceView(
		finalLookupTexture.Get(), &srvDesc, BRDF_Lookup_Texture.GetAddressOf());

	// Save current render target and depth buffer
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> prevRTV;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> prevDSV;
	context->OMGetRenderTargets(1, prevRTV.GetAddressOf(), prevDSV.GetAddressOf());
	// Save current viewport
	unsigned int vpCount = 1;
	D3D11_VIEWPORT prevVP = {};
	context->RSGetViewports(&vpCount, &prevVP);

	// Make sure the viewport matches the texture size
	D3D11_VIEWPORT vp = {};
	vp.Width = (float)sizeOfLookupTexture;
	vp.Height = (float)sizeOfLookupTexture;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	context->RSSetViewports(1, &vp);
	// Set states that may or may not be set yet
	context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	std::shared_ptr <SimpleVertexShader> fullscreenVS = LoadShader(SimpleVertexShader, L"FullScreenVS.cso");
	std::shared_ptr<SimplePixelShader> IBLBrdfLookUpTablePS = LoadShader(SimplePixelShader, L"IBLBrdfLookUpTablePS.cso");

	fullscreenVS->SetShader();
	IBLBrdfLookUpTablePS->SetShader();
	IBLBrdfLookUpTablePS->SetShaderResourceView("EnvironmentMap", skySRV.Get()); // Skybox texture itself
	IBLBrdfLookUpTablePS->SetSamplerState("BasicSampler", samplerOptions.Get());

	// Make a render target view for this whole texture
	D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
	rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D; // This points to a Texture2D
	rtvDesc.Texture2D.MipSlice = 0; // Which mip are we rendering into?
	rtvDesc.Format = texDesc.Format; // Match the format of the texture

	//Have a comptr for a render target view
	//you will past that to this create function
	//after this create fucntion you need to set the current render target
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> rtv;
	device->CreateRenderTargetView(finalLookupTexture.Get(),&rtvDesc, rtv.GetAddressOf());

	// Clear and set this render target
	float black[4] = {}; // Initialize to all zeroes
	context->ClearRenderTargetView(rtv.Get(), black);
	context->OMSetRenderTargets(1, rtv.GetAddressOf(), 0);

	// Render exactly 3 vertices
	context->Draw(3, 0);
	// Ensure we flush the graphics pipe to so that we don't cause
	// a hardware timeout which can result in a driver crash
	// NOTE: This might make C++ sit and wait for a sec! Better than a crash!
	context->Flush();
	// Restore the old render target and viewport
	context->OMSetRenderTargets(1, prevRTV.GetAddressOf(), prevDSV.Get());
	context->RSSetViewports(1, &prevVP);
}

void Sky::computeShaderSkyShiftDay()
{
	for (int x = 0; x < 6; x++)
		currentTextures[x] = daySkyTextures[x];
}

void Sky::SetDeltaTime(float deltaTime)
{
	skyDeltaTime = deltaTime;
}

void Sky::computeShaderSkyShiftNight()
{
	for (int x = 0; x < 6; x++)
		currentTextures[x] = nightSkyTextures[x];
}
