I choice option 1, and expirenmented with shifting the textures for the sky box using compute shaders, 
I have the skybox shifting form a day sky to a night sky than back to a day sky. by lerping between the 2 textures
within the compute shader. Thanks alot chris I know it was a pain having to deal with me at the end,
but i really appricate your help

-Daniel Joseph Jr.
