module.exports.Account = require('./Account.js');
module.exports.Post = require('./Post.js');
module.exports.fileControl = require('./fileControl.js');
